package com.example.aulaboleto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaboletoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AulaboletoApplication.class, args);
    }

}
