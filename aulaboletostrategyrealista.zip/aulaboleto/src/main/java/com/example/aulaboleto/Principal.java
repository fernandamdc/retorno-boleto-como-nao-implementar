package com.example.aulaboleto;
//Aula boleto exemplo Realista
public class Principal {
    public static void main(String[] args) {
        LeituraRetorno leituraRetorno = new LeituraRetornoBancoBrasil();
        ProcessarBoletos processador = new ProcessarBoletos(leituraRetorno);
        //processador.setLeituraRetorno(leituraRetorno);
        processador.processar("");
    }
}
