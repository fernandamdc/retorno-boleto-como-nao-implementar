import java.util.List;

public class ProcessarBoletos {
    private LeituraRetorno leituraRetorno;

    public ProcessarBoletos(LeituraRetorno leituraRetorno){
        this.leituraRetorno = leituraRetorno;
    }
    public void processar (String nomeArquivo){
        System.out.println("Processando arquivo "+nomeArquivo);

        leituraRetorno.lerArquivo(nomeArquivo);

    }

    public void setLeituraRetorno(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }
}



